package com.framecheckmate.userservice.controller;

import com.framecheckmate.userservice.entity.RefreshToken;
import org.springframework.security.core.token.TokenService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@ResponseBody
public class TokenController {
    private final TokenService tokenService;

    @PostMapping("/token")
    public String getToken(@RequestBody RefreshToken refreshToken) {
        return tokenService.generateAccessToken(refreshToken);
    }
}
