package com.framecheckmate.userservice.entity;

import lombok.Getter;
import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

import java.util.UUID;

@Getter
@RedisHash(value = "refreshToken", timeToLive = 14440)
public class RefreshToken {
    @Id
    private String refreshToken;
    private UUID member_id;

    public RefreshToken(String refreshToken, UUID member_id) {
        this.refreshToken = refreshToken;
        this.member_id = member_id;
    }

}
