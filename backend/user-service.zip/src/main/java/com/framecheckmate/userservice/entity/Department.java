package com.framecheckmate.userservice.entity;

public class Department {
}
