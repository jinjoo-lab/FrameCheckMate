package com.framecheckmate.userservice.service;

import com.framecheckmate.userservice.repository.RefreshTokenRepository;
import com.framecheckmate.userservice.repository.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

@Transactional
@Service
public class TokenService {

    private final RefreshTokenRepository refreshTokenRepository;
    private final UserRepository userRepository;
}
