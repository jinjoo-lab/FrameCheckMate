package com.framecheckmate.userservice.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.UUID;

@Entity
@Table(name = "Member")
@Getter
@Setter
public class Member {
    @Id
    @Column(columnDefinition = "BINARY(16)", nullable = false)
    private UUID member_id = UUID.randomUUID();
    private String name;
    private String email;
    private String image;
    private String password;
    private String role;

}


