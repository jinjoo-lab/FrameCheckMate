package com.framecheckmate.userservice.entity;

public class Project {
}
