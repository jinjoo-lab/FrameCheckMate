package com.framecheckmate.userservice.repository;

import com.framecheckmate.userservice.entity.Member;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<Member, Integer> {
    Boolean existsByUsername(String username);

    Member findByUsername(String username);

}
