package com.framecheckmate.userservice.project.dto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProjectCreateDTO {
    private String name;
}